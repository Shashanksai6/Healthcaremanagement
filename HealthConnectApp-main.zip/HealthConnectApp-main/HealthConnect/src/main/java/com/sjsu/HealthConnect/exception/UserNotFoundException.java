package com.sjsu.HealthConnect.exception;

import org.springframework.stereotype.Component;

@Component
public class UserNotFoundException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
