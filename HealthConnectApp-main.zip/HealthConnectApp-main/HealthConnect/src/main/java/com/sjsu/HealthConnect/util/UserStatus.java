package com.sjsu.HealthConnect.util;

public enum UserStatus {
    ACTIVE,
    INACTIVE
}
