package com.sjsu.HealthConnect.util;

public enum UserRole {
    PATIENT,
    DOCTOR,
    SUPER_ADMIN,
    STAFF,
    ADMIN
}

